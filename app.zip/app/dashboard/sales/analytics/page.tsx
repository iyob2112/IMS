"use client";

import {
  TrendingUp,
  DollarSign,
  ShoppingCart,
  Users,
  Download,
  Calendar,
} from "lucide-react";

export default function SalesAnalyticsPage() {
  return (
    <div className="min-h-screen bg-[#0B1120] text-white p-3 pt-10 space-y-6">

      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between gap-4">

        <div>
          <h1 className="text-4xl font-bold">
            Sales Analytics
          </h1>

          <p className="text-slate-400 mt-2">
            Revenue insights, growth trends and performance metrics
          </p>
        </div>

        <div className="flex gap-3">

          <button className="bg-[#131C31] px-4 py-3 rounded-xl border border-slate-700">
            <Calendar size={18} />
          </button>

          <button className="bg-green-600 px-5 py-3 rounded-xl flex items-center gap-2">
            <Download size={18} />
            Export Excel
          </button>

          <button className="bg-red-600 px-5 py-3 rounded-xl flex items-center gap-2">
            <Download size={18} />
            Export PDF
          </button>

        </div>

      </div>

      {/* KPI Cards */}
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <DollarSign className="text-green-400 mb-3" />
          <p className="text-slate-400">Revenue</p>
          <h2 className="text-4xl font-bold">$254,500</h2>
          <span className="text-green-400 text-sm">
            +12.4%
          </span>
        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <ShoppingCart className="text-cyan-400 mb-3" />
          <p className="text-slate-400">Orders</p>
          <h2 className="text-4xl font-bold">8,245</h2>
          <span className="text-green-400 text-sm">
            +8.1%
          </span>
        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <Users className="text-orange-400 mb-3" />
          <p className="text-slate-400">Customers</p>
          <h2 className="text-4xl font-bold">3,124</h2>
          <span className="text-green-400 text-sm">
            +15.7%
          </span>
        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <TrendingUp className="text-purple-400 mb-3" />
          <p className="text-slate-400">Profit</p>
          <h2 className="text-4xl font-bold">$84,200</h2>
          <span className="text-green-400 text-sm">
            +11.2%
          </span>
        </div>

      </div>

      {/* Charts */}
      <div className="grid xl:grid-cols-2 gap-6">

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <h2 className="text-xl font-bold mb-6">
            Revenue Trend
          </h2>

          <div className="h-[350px] rounded-2xl bg-[#1A2742] flex items-center justify-center">
            Revenue Chart
          </div>
        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <h2 className="text-xl font-bold mb-6">
            Sales Growth
          </h2>

          <div className="h-[350px] rounded-2xl bg-[#1A2742] flex items-center justify-center">
            Growth Chart
          </div>
        </div>

      </div>

      {/* Performance Tables */}
      <div className="grid xl:grid-cols-2 gap-6">

        {/* Top Products */}
        <div className="bg-[#131C31] p-6 rounded-3xl">

          <h2 className="text-xl font-bold mb-6">
            Top Selling Products
          </h2>

          <div className="space-y-4">

            {[
              "Laptop",
              "Mouse",
              "Keyboard",
              "Monitor",
              "Printer",
            ].map((item, index) => (
              <div
                key={index}
                className="bg-[#1A2742] p-4 rounded-xl flex justify-between"
              >
                <span>{item}</span>
                <span className="text-green-400">
                  {500 - index * 50} Sales
                </span>
              </div>
            ))}

          </div>

        </div>

        {/* Top Customers */}
        <div className="bg-[#131C31] p-6 rounded-3xl">

          <h2 className="text-xl font-bold mb-6">
            Top Customers
          </h2>

          <div className="space-y-4">

            {[
              "John Doe",
              "Sarah Smith",
              "Michael Johnson",
              "David Wilson",
            ].map((customer, index) => (
              <div
                key={index}
                className="bg-[#1A2742] p-4 rounded-xl flex justify-between"
              >
                <span>{customer}</span>

                <span className="text-cyan-400">
                  ${(12000 - index * 1500).toLocaleString()}
                </span>
              </div>
            ))}

          </div>

        </div>

      </div>

      {/* Breakdown */}
      <div className="grid xl:grid-cols-3 gap-6">

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <h2 className="text-xl font-bold mb-6">
            Payment Methods
          </h2>

          <div className="space-y-4">

            <div className="flex justify-between">
              <span>Cash</span>
              <span className="text-green-400">45%</span>
            </div>

            <div className="flex justify-between">
              <span>Bank</span>
              <span className="text-cyan-400">30%</span>
            </div>

            <div className="flex justify-between">
              <span>Mobile Money</span>
              <span className="text-orange-400">25%</span>
            </div>

          </div>
        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl">
          <h2 className="text-xl font-bold mb-6">
            Sales Forecast
          </h2>

          <div className="h-[200px] rounded-2xl bg-[#1A2742] flex items-center justify-center">
            Forecast Chart
          </div>
        </div>

        <div className="bg-gradient-to-r from-cyan-600 to-blue-600 p-6 rounded-3xl">

          <h2 className="text-2xl font-bold">
            Executive Summary
          </h2>

          <p className="mt-4 text-white/90">
            Revenue increased by 12.4% this month.
            Top category remains Electronics with
            38% of total sales. Customer growth
            increased 15.7%.
          </p>

        </div>

      </div>

    </div>
  );
}