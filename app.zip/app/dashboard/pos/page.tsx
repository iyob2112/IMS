"use client";

import { useState } from "react";
import {
  Search,
  Plus,
  Minus,
  ShoppingCart,
} from "lucide-react";
interface Product {
  id: number;
  name: string;
  price: number;
}

interface CartItem extends Product {
  quantity: number;
}

const products = [
  {
    id: 1,
    name: "Laptop",
    price: 1200,
  },
  {
    id: 2,
    name: "Mouse",
    price: 25,
  },
  {
    id: 3,
    name: "Keyboard",
    price: 80,
  },
  {
    id: 4,
    name: "Monitor",
    price: 350,
  },
];

export default function POSPage() {
const [cart, setCart] = useState<CartItem[]>([]);

 const addToCart = (product: Product) => {
    const exists = cart.find(
      (item) => item.id === product.id
    );

    if (exists) {
      setCart(
        cart.map((item) =>
          item.id === product.id
            ? {
                ...item,
                quantity: item.quantity + 1,
              }
            : item
        )
      );
    } else {
      setCart([
        ...cart,
        {
          ...product,
          quantity: 1,
        },
      ]);
    }
  };

  const increase = (id: number) => {
    setCart(
      cart.map((item) =>
        item.id === id
          ? {
              ...item,
              quantity: item.quantity + 1,
            }
          : item
      )
    );
  };

  const decrease = (id: number) => {
    setCart(
      cart
        .map((item) =>
          item.id === id
            ? {
                ...item,
                quantity: item.quantity - 1,
              }
            : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const subtotal = cart.reduce(
    (sum, item) =>
      sum + item.price * item.quantity,
    0
  );

  const tax = subtotal * 0.15;

  const total = subtotal + tax;

  return (
    <div className="min-h-screen bg-[#0B1120] text-white pt-10 p-3">

      <div className="mb-8">
        <h1 className="text-4xl font-bold text-white">
          POS System
        </h1>

        <p className="text-slate-400">
          Point Of Sale
        </p>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">

        {/* Products */}
        <div className="lg:col-span-2">

          <div className="bg-[#131C31] rounded-3xl border border-slate-800 p-6 mb-6">

            <div className="flex items-center bg-[#0B1120] rounded-xl border border-slate-700 px-4 py-3">

              <Search
                size={18}
                className="text-slate-400"
              />

              <input
                placeholder="Search products..."
                className="bg-transparent outline-none ml-3 text-white w-full"
              />

            </div>

          </div>

          <div className="grid md:grid-cols-2 xl:grid-cols-3 gap-6">

            {products.map((product) => (
              <div
                key={product.id}
                className="bg-[#131C31] rounded-3xl border border-slate-800 p-5"
              >
                <div className="h-32 bg-[#0B1120] rounded-2xl mb-4"></div>

                <h3 className="text-white font-bold text-lg">
                  {product.name}
                </h3>

                <p className="text-cyan-400 mt-2">
                  ${product.price}
                </p>

                <button
                  onClick={() =>
                    addToCart(product)
                  }
                  className="w-full mt-4 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl p-3"
                >
                  Add To Cart
                </button>

              </div>
            ))}

          </div>

        </div>

        {/* Cart */}
        <div className="bg-[#131C31] rounded-3xl border border-slate-800 p-6">

          <div className="flex items-center gap-2 mb-6">
            <ShoppingCart className="text-cyan-400" />

            <h2 className="text-2xl font-bold text-white">
              Cart
            </h2>
          </div>

          <div className="space-y-4">

            {cart.map((item) => (
              <div
                key={item.id}
                className="bg-[#0B1120] rounded-xl p-4"
              >
                <div className="flex justify-between mb-3">

                  <h3 className="text-white">
                    {item.name}
                  </h3>

                  <span className="text-cyan-400">
                    ${item.price}
                  </span>

                </div>

                <div className="flex items-center gap-2">

                  <button
                    onClick={() =>
                      decrease(item.id)
                    }
                    className="bg-red-500 p-2 rounded-lg"
                  >
                    <Minus size={16} />
                  </button>

                  <span className="text-white px-4">
                    {item.quantity}
                  </span>

                  <button
                    onClick={() =>
                      increase(item.id)
                    }
                    className="bg-green-500 p-2 rounded-lg"
                  >
                    <Plus size={16} />
                  </button>

                </div>

              </div>
            ))}

          </div>

          <div className="border-t border-slate-700 mt-6 pt-6 space-y-3">

            <div className="flex justify-between">
              <span className="text-slate-400">
                Subtotal
              </span>

              <span className="text-white">
                ${subtotal.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between">
              <span className="text-slate-400">
                Tax (15%)
              </span>

              <span className="text-white">
                ${tax.toFixed(2)}
              </span>
            </div>

            <div className="flex justify-between text-xl font-bold">

              <span className="text-white">
                Total
              </span>

              <span className="text-green-400">
                ${total.toFixed(2)}
              </span>

            </div>

          </div>

          <div className="mt-6">

            <select className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white mb-4">
              <option>Cash</option>
              <option>Card</option>
              <option>Bank Transfer</option>
              <option>Mobile Money</option>
            </select>

            <button className="w-full bg-green-600 hover:bg-green-700 text-white p-4 rounded-xl font-bold">
              Complete Sale
            </button>

          </div>

        </div>

      </div>

    </div>
  );
}