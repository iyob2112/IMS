"use client";

import {
  PackagePlus,
  DollarSign,
  Calendar,
  AlertCircle,
} from "lucide-react";
import Link from "next/link";
import StockInForm from "@/components/StockInForm";
import StockTable from "@/components/StockTable";

export default function StockInPage() {
  return (
    <div className="space-y-6 pt-10 p-3 text-white min-h-screen h-full">

      {/* Header */}
      <div className="flex justify-between items-center">

        <div>
          <h1 className="text-4xl font-bold text-white">
            Stock In Management
          </h1>

          <p className="text-slate-400 mt-2">
            Receive inventory and manage stock entries
          </p>
        </div>

      </div>

      {/* Statistics */}
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">

        <div className="bg-[#131C31] p-6 rounded-3xl border border-slate-800">

          <div className="flex justify-between">

            <div>
              <p className="text-slate-400">
                Stock Received
              </p>

              <h2 className="text-4xl font-bold text-white mt-2">
                2,540
              </h2>
            </div>

            <PackagePlus className="text-cyan-400" />

          </div>

        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl border border-slate-800">

          <div className="flex justify-between">

            <div>
              <p className="text-slate-400">
                Today`s Receipts
              </p>

              <h2 className="text-4xl font-bold text-green-400 mt-2">
                42
              </h2>
            </div>

            <Calendar className="text-green-400" />

          </div>

        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl border border-slate-800">

          <div className="flex justify-between">

            <div>
              <p className="text-slate-400">
                Inventory Value
              </p>

              <h2 className="text-4xl font-bold text-purple-400 mt-2">
                $34K
              </h2>
            </div>

            <DollarSign className="text-purple-400" />

          </div>

        </div>

        <div className="bg-[#131C31] p-6 rounded-3xl border border-slate-800">

          <div className="flex justify-between">

            <div>
              <p className="text-slate-400">
                Pending Receipts
              </p>

              <h2 className="text-4xl font-bold text-red-400 mt-2">
                5
              </h2>
            </div>

            <AlertCircle className="text-red-400" />

          </div>

        </div>

      </div>

      {/* Quick Actions */}
  <div className="grid md:grid-cols-2 xl:grid-cols-6 gap-4">

  <Link
    href="/dashboard/stock-in"
    className="bg-cyan-600 p-4 rounded-2xl text-center"
  >
    Add Stock
  </Link>

  <Link
    href="/dashboard/stock-in/history"
    className="bg-violet-600 p-4 rounded-2xl text-center"
  >
    History
  </Link>

  <Link
    href="/dashboard/stock-in/grn"
    className="bg-green-600 p-4 rounded-2xl text-center"
  >
    GRN
  </Link>

  <Link
    href="/dashboard/stock-in/batches"
    className="bg-orange-600 p-4 rounded-2xl text-center"
  >
    Batches
  </Link>

  <Link
    href="/dashboard/stock-in/barcodes"
    className="bg-pink-600 p-4 rounded-2xl text-center"
  >
    Barcodes
  </Link>

  <button className="bg-indigo-600 p-4 rounded-2xl">
    Import CSV
  </button>

</div>

      {/* Stock Form */}
      <div className="bg-[#131C31] border border-slate-800 rounded-3xl p-6">

        <h2 className="text-xl font-bold text-white mb-6">
          Receive Inventory
        </h2>

        <StockInForm />

      </div>

      {/* Stock History */}
      <div className="bg-[#131C31] border border-slate-800 rounded-3xl p-6">

        <h2 className="text-xl font-bold text-white mb-6">
          Recent Stock Entries
        </h2>

        <StockTable />

      </div>

    </div>
  );
}