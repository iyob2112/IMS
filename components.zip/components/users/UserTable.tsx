"use client";

import { User } from "@/types/user";
import {
  Eye,
  Pencil,
  Trash2,
} from "lucide-react";

interface Props {
  users: User[];
}

export default function UserTable({
  users,
}: Props) {
  return (
    <div className="overflow-x-auto">

      <table className="w-full">

        <thead>
          <tr className="border-b border-slate-700 text-slate-400">
            <th className="text-left p-4">Name</th>
            <th className="text-left p-4">Email</th>
            <th className="text-left p-4">Role</th>
            <th className="text-left p-4">Status</th>
            <th className="text-left p-4">Actions</th>
          </tr>
        </thead>

        <tbody>

          {users.map((user) => (
            <tr
              key={user.id}
              className="border-b border-slate-800"
            >
              <td className="p-4 text-white">
                {user.name}
              </td>

              <td className="p-4 text-slate-300">
                {user.email}
              </td>

              <td className="p-4">

                <span className="bg-cyan-500/20 text-cyan-400 px-3 py-1 rounded-full text-xs">
                  {user.role}
                </span>

              </td>

              <td className="p-4">

                <span
                  className={`px-3 py-1 rounded-full text-xs ${
                    user.status === "Active"
                      ? "bg-green-500/20 text-green-400"
                      : "bg-red-500/20 text-red-400"
                  }`}
                >
                  {user.status}
                </span>

              </td>

              <td className="p-4">

                <div className="flex gap-2">

                  <button className="p-2 rounded-lg bg-slate-800">
                    <Eye size={16} />
                  </button>

                  <button className="p-2 rounded-lg bg-slate-800">
                    <Pencil size={16} />
                  </button>

                  <button className="p-2 rounded-lg bg-red-500/20 text-red-400">
                    <Trash2 size={16} />
                  </button>

                </div>

              </td>
            </tr>
          ))}

        </tbody>

      </table>

    </div>
  );
}