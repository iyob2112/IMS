"use client";

import { Purchase } from "@/types/purchase";
import { Eye, Pencil, Trash2 } from "lucide-react";

interface Props {
  purchases: Purchase[];
}

export default function PurchaseTable({
  purchases,
}: Props) {
  return (
    <div className="overflow-x-auto">

      <table className="w-full">

        <thead>
          <tr className="border-b border-slate-700 text-slate-400">
            <th className="text-left p-4">
              Purchase No
            </th>

            <th className="text-left p-4">
              Supplier
            </th>

            <th className="text-left p-4">
              Date
            </th>

            <th className="text-left p-4">
              Amount
            </th>

            <th className="text-left p-4">
              Status
            </th>

            <th className="text-left p-4">
              Actions
            </th>
          </tr>
        </thead>

        <tbody>

          {purchases.map((purchase) => (
            <tr
              key={purchase.id}
              className="border-b border-slate-800"
            >
              <td className="p-4 text-white">
                {purchase.purchaseNo}
              </td>

              <td className="p-4 text-slate-300">
                {purchase.supplier}
              </td>

              <td className="p-4 text-slate-300">
                {purchase.date}
              </td>

              <td className="p-4 text-green-400">
                ${purchase.amount}
              </td>

              <td className="p-4">
                <span
                  className={`px-3 py-1 rounded-full text-xs ${
                    purchase.status === "Completed"
                      ? "bg-green-500/20 text-green-400"
                      : purchase.status === "Pending"
                      ? "bg-yellow-500/20 text-yellow-400"
                      : "bg-red-500/20 text-red-400"
                  }`}
                >
                  {purchase.status}
                </span>
              </td>

              <td className="p-4">
                <div className="flex gap-2">

                  <button className="p-2 rounded-lg bg-slate-800">
                    <Eye size={16} />
                  </button>

                  <button className="p-2 rounded-lg bg-slate-800">
                    <Pencil size={16} />
                  </button>

                  <button className="p-2 rounded-lg bg-red-500/20 text-red-400">
                    <Trash2 size={16} />
                  </button>

                </div>
              </td>
            </tr>
          ))}

        </tbody>

      </table>

    </div>
  );
}