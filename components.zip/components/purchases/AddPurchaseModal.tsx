"use client";

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function AddPurchaseModal({
  open,
  onClose,
}: Props) {
  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center">

      <div className="bg-[#131C31] border border-slate-700 rounded-3xl p-6 w-full max-w-xl">

        <div className="flex justify-between mb-6">

          <h2 className="text-2xl font-bold text-white">
            New Purchase
          </h2>

          <button
            onClick={onClose}
            className="text-slate-400"
          >
            ✕
          </button>

        </div>

        <form className="space-y-4">

          <input
            placeholder="Purchase Number"
            className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white"
          />

          <input
            placeholder="Supplier Name"
            className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white"
          />

          <input
            type="date"
            className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white"
          />

          <input
            type="number"
            placeholder="Amount"
            className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white"
          />

          <select className="w-full bg-[#0B1120] border border-slate-700 rounded-xl p-3 text-white">
            <option>Pending</option>
            <option>Completed</option>
            <option>Cancelled</option>
          </select>

          <button
            type="button"
            className="w-full bg-cyan-600 hover:bg-cyan-700 p-3 rounded-xl text-white"
          >
            Save Purchase
          </button>

        </form>

      </div>

    </div>
  );
}