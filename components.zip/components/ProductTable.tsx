"use client";

import { useState } from "react";
import Image from "next/image";
import {
  Eye,
  Pencil,
  Trash2,
  Barcode,
  MoreVertical,
} from "lucide-react";
import Link from "next/link";
import { products } from "@/data/products";

export default function ProductTable() {
  const [selected, setSelected] = useState<number[]>([]);

  const toggleSelect = (id: number) => {
    if (selected.includes(id)) {
      setSelected(selected.filter((x) => x !== id));
    } else {
      setSelected([...selected, id]);
    }
  };

  return (
    <div>

      {/* Bulk Actions */}

      {selected.length > 0 && (
        <div className="mb-4 flex items-center gap-3 bg-[#0B1120] border border-slate-800 rounded-2xl p-4">

          <span className="text-white">
            {selected.length} selected
          </span>

          <button className="bg-green-600 px-4 py-2 rounded-xl">
            Export
          </button>

          <button className="bg-red-600 px-4 py-2 rounded-xl">
            Delete
          </button>

        </div>
      )}

      <div className="overflow-x-auto">

        <table className="w-full">

          <thead>

            <tr className="border-b border-slate-800 text-slate-400">

              <th className="p-4">
                <input type="checkbox" />
              </th>

              <th className="p-4 text-left">
                Image
              </th>

              <th className="p-4 text-left">
                SKU
              </th>

              <th className="p-4 text-left">
                Product
              </th>

              <th className="p-4 text-left">
                Category
              </th>

              <th className="p-4 text-left">
                Cost
              </th>

              <th className="p-4 text-left">
                Price
              </th>

              <th className="p-4 text-left">
                Stock
              </th>

              <th className="p-4 text-left">
                Status
              </th>

              <th className="p-4 text-left">
                Actions
              </th>

            </tr>

          </thead>

          <tbody>

            {products.map((product) => {

              const status =
                product.stock === 0
                  ? "Out Of Stock"
                  : product.stock < 10
                  ? "Low Stock"
                  : "In Stock";

              return (
                <tr
                  key={product.id}
                  className="border-b border-slate-800 hover:bg-[#0B1120]"
                >

                  <td className="p-4">

                    <input
                      type="checkbox"
                      checked={selected.includes(product.id)}
                      onChange={() =>
                        toggleSelect(product.id)
                      }
                    />

                  </td>

                  <td className="p-4">

                    <img
                      src={product.image}
                      alt={product.name}
                      width={50}
                      height={50}
                      className="rounded-lg"
                    />

                  </td>

                  <td className="p-4 text-cyan-400">
                    {product.sku}
                  </td>

                  <td className="p-4 text-white">
                    {product.name}
                  </td>

                  <td className="p-4 text-slate-300">
                    {product.category}
                  </td>

                  <td className="p-4 text-white">
                    ${product.purchasePrice}
                  </td>

                  <td className="p-4 text-green-400">
                    ${product.sellingPrice}
                  </td>

                  <td className="p-4 text-white">
                    {product.stock}
                  </td>

                  <td className="p-4">

                    <span
                      className={`px-3 py-1 rounded-full text-xs ${
                        status === "In Stock"
                          ? "bg-green-500/20 text-green-400"
                          : status === "Low Stock"
                          ? "bg-yellow-500/20 text-yellow-400"
                          : "bg-red-500/20 text-red-400"
                      }`}
                    >
                      {status}
                    </span>

                  </td>

                  <td className="p-4">

                    <div className="flex gap-2">

                    <Link
  href={`/dashboard/products/${product.id}`}
  className="bg-slate-800 p-2 rounded-lg"
>
  <Eye size={16} />
</Link>

                      <button className="bg-slate-800 p-2 rounded-lg">
                        <Pencil size={16} />
                      </button>

                      <button className="bg-slate-800 p-2 rounded-lg">
                        <Barcode size={16} />
                      </button>

                      <button className="bg-red-500/20 text-red-400 p-2 rounded-lg">
                        <Trash2 size={16} />
                      </button>

                    </div>

                  </td>

                </tr>
              );
            })}

          </tbody>

        </table>

      </div>

      {/* Pagination */}

      <div className="flex justify-between items-center mt-6">

        <p className="text-slate-400">
          Showing 1–10 of 150 products
        </p>

        <div className="flex gap-2">

          <button className="bg-[#131C31] border border-slate-800 px-4 py-2 rounded-xl">
            Previous
          </button>

          <button className="bg-cyan-600 px-4 py-2 rounded-xl">
            1
          </button>

          <button className="bg-[#131C31] border border-slate-800 px-4 py-2 rounded-xl">
            2
          </button>

          <button className="bg-[#131C31] border border-slate-800 px-4 py-2 rounded-xl">
            Next
          </button>

        </div>

      </div>

    </div>
  );
}